# Live TV (Kotlin + WebView + Media3)

Hybrid Android app. Browsing UI (channel grid, search, categories, favorites)
is a single HTML page in a WebView; playback is a native Media3 ExoPlayer
activity with picture-in-picture.

    app/src/main/java/com/livetv/android/
      MainActivity.kt          hosts the WebView + JS bridge
      web/TvHtml.kt            whole UI as one HTML/CSS/JS string
      web/TvBridge.kt          JS <-> Kotlin bridge ("NativeTv")
      data/ChannelRepository   live Firebase listener on /channels
      data/FavoritesStore      favorites kept on-device (SharedPreferences)
      player/PlayerActivity    ExoPlayer, HLS/DASH, retry, PiP

## REQUIRED before the first build: google-services.json

The build applies the Google Services plugin, so `app/google-services.json`
must exist and contain a client entry for the package **com.livetv.android**.
It is intentionally NOT included (it holds your project's API keys).

Option A - reuse your existing Firebase project (ug-netflix-1044d):
  1. Firebase console > Project settings > Your apps > Add app > Android
  2. Package name: com.livetv.android
  3. Download google-services.json and put it in app/

Option B - keep your existing file and rename this app to match an entry
already in it (com.netflixadmin.android, com.my.movies or com.ugnet.android):
change `namespace` and `applicationId` in app/build.gradle.kts, and move the
sources from com/livetv/android to the new package path.
(Two apps must not share an applicationId on one device.)

## Firebase data

Channels live at /channels/{id}. Only `name` and `streamUrl` are required.

    {
      "name": "News One",
      "streamUrl": "https://example.com/live/index.m3u8",
      "logo": "https://example.com/logo.png",
      "category": "News",
      "country": "UG",
      "language": "en",
      "sortOrder": 1,
      "published": true,
      "userAgent": "",      // optional, some streams need a specific UA
      "referer": ""         // optional, some streams need a Referer header
    }

Channels with `published: false` are hidden. Edits in the console (or your
admin app) appear in the app instantly.

### Database rules

The app reads without signing in, so /channels must be publicly readable.
Keep writes locked down:

    {
      "rules": {
        "channels": {
          ".read": true,
          ".write": "auth != null && root.child('admins').child(auth.uid).child('enabled').val() === true"
        }
      }
    }

Leave the rest of your rules alone. Do not open write access to everyone.

## Build

Needs JDK 17 and Android SDK platform 35.

    ./gradlew assembleDebug
    # app/build/outputs/apk/debug/app-debug.apk

On desktop, Android Studio creates local.properties for you.
