package com.livetv.android.model

/**
 * One live channel. Every field has a default so Firebase / JSON parsing
 * never fails on a partially filled record.
 *
 * Firebase path: /channels/{id}
 */
data class Channel(
    val id: String = "",
    val name: String = "",
    val logo: String = "",
    val streamUrl: String = "",
    val category: String = "General",
    val country: String = "",
    val language: String = "",
    val description: String = "",
    val userAgent: String = "",
    val referer: String = "",
    val sortOrder: Int = 0,
    val published: Boolean = true
)
