package com.livetv.android

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.livetv.android.data.ChannelRepository
import com.livetv.android.data.FavoritesStore
import com.livetv.android.web.TvBridge
import com.livetv.android.web.TvHtml

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var bridge: TvBridge
    private lateinit var auth: FirebaseAuth
    private lateinit var googleClient: GoogleSignInClient

    companion object {
        private const val RC_GOOGLE_SIGN_IN = 7001
        private const val WEB_CLIENT_ID =
            "354161590396-n2s2v550medc9rkn3dso68rouuatut6j.apps.googleusercontent.com"
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()
        googleClient = GoogleSignIn.getClient(
            this,
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(WEB_CLIENT_ID)
                .requestEmail()
                .build()
        )

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
        }
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.webChromeClient = WebChromeClient()

        bridge = TvBridge(
            context = this,
            repo = ChannelRepository(),
            favorites = FavoritesStore(this),
            webView = web,
            auth = auth,
            onGoogleSignInRequested = {
                startActivityForResult(googleClient.signInIntent, RC_GOOGLE_SIGN_IN)
            }
        )
        web.addJavascriptInterface(bridge, "NativeTv")

        web.loadDataWithBaseURL(
            "https://tv.local/",
            TvHtml.page(),
            "text/html",
            "UTF-8",
            null
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != RC_GOOGLE_SIGN_IN) return

        try {
            val account = GoogleSignIn.getSignedInAccountFromIntent(data)
                .getResult(ApiException::class.java)
            val idToken = account.idToken
            if (idToken.isNullOrBlank()) {
                bridge.reportAuthError("Google sign-in could not get an ID token.")
                return
            }

            auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null))
                .addOnSuccessListener {
                    bridge.reportAuthSuccess()
                }
                .addOnFailureListener {
                    bridge.reportAuthError(
                        it.localizedMessage ?: "Google sign-in failed."
                    )
                }
        } catch (e: ApiException) {
            if (e.statusCode != 12501) {
                bridge.reportAuthError("Google sign-in was not completed.")
            }
        } catch (e: Exception) {
            bridge.reportAuthError(e.localizedMessage ?: "Google sign-in failed.")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.TvUI.onBack()") { handled ->
            if (handled != "true") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        bridge.stop()
        web.removeJavascriptInterface("NativeTv")
        web.destroy()
        super.onDestroy()
    }
}
