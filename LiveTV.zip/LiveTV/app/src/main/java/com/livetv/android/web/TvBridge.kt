package com.livetv.android.web

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.livetv.android.data.ChannelRepository
import com.livetv.android.data.FavoritesStore
import com.livetv.android.player.PlayerActivity
import org.json.JSONObject
import java.util.UUID

class TvBridge(
    private val context: Context,
    private val repo: ChannelRepository,
    private val favorites: FavoritesStore,
    private val webView: WebView,
    private val auth: FirebaseAuth,
    private val onGoogleSignInRequested: () -> Unit
) {

    @JavascriptInterface
    fun ready() {
        if (auth.currentUser == null) {
            post("window.TvUI.showAuth();")
        } else {
            startChannelObserver()
        }
    }

    @JavascriptInterface
    fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { reportAuthSuccess() }
            .addOnFailureListener {
                reportAuthError(it.localizedMessage ?: "Sign in failed.")
            }
    }

    @JavascriptInterface
    fun createAccount(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { reportAuthSuccess() }
            .addOnFailureListener {
                reportAuthError(it.localizedMessage ?: "Could not create account.")
            }
    }

    @JavascriptInterface
    fun googleSignIn() {
        webView.post { onGoogleSignInRequested() }
    }

    @JavascriptInterface
    fun signOut() {
        auth.signOut()
        webView.post { post("window.TvUI.showAuth();") }
    }

    @JavascriptInterface
    fun getFavorites(): String = favorites.toJson()

    @JavascriptInterface
    fun toggleFavorite(id: String): Boolean = favorites.toggle(id)

    @JavascriptInterface
    fun play(url: String, name: String, userAgent: String, referer: String) {
        if (url.isBlank()) return
        webView.post {
            PlayerActivity.start(context, url, name, userAgent, referer)
        }
    }

    @JavascriptInterface
    fun toast(msg: String) {
        webView.post { Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
    }

    fun reportAuthSuccess() {
        webView.post {
            post("window.TvUI.authSuccess();")
            startChannelObserver()
        }
    }

    fun reportAuthError(message: String) {
        webView.post {
            post("window.TvUI.authError(${JSONObject.quote(message)});")
        }
    }

    private fun startChannelObserver() {
        repo.observe(
            { json -> postLargeJson(json) },
            { message -> post("window.TvUI.onError(${JSONObject.quote(message)});") }
        )
    }

    fun stop() = repo.stop()

    private fun post(js: String) {
        webView.post { webView.evaluateJavascript(js, null) }
    }

    private fun postLargeJson(json: String) {
        val id = UUID.randomUUID().toString()
        val size = 48_000
        val total = if (json.isEmpty()) 1 else (json.length + size - 1) / size

        webView.post {
            webView.evaluateJavascript(
                "window.TvUI.dataStart(${JSONObject.quote(id)},$total);",
                null
            )
            if (json.isEmpty()) {
                webView.evaluateJavascript(
                    "window.TvUI.dataChunk(${JSONObject.quote(id)},0,${JSONObject.quote("")});",
                    null
                )
            } else {
                var index = 0
                var start = 0
                while (start < json.length) {
                    val end = minOf(start + size, json.length)
                    webView.evaluateJavascript(
                        "window.TvUI.dataChunk(${JSONObject.quote(id)},$index," +
                            "${JSONObject.quote(json.substring(start, end))});",
                        null
                    )
                    start = end
                    index++
                }
            }
            webView.evaluateJavascript(
                "window.TvUI.dataEnd(${JSONObject.quote(id)});",
                null
            )
        }
    }
}
