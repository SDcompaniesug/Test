package com.livetv.android.data

import android.content.Context
import org.json.JSONArray

/** Favorites live on the device only, as a JSON array of channel ids. */
class FavoritesStore(context: Context) {

    private val prefs = context.getSharedPreferences("livetv", Context.MODE_PRIVATE)

    fun ids(): List<String> {
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun toJson(): String = JSONArray(ids()).toString()

    /** Returns true if the channel is now a favorite, false if it was removed. */
    fun toggle(id: String): Boolean {
        if (id.isBlank()) return false
        val list = ids().toMutableList()
        val nowFav = if (list.contains(id)) {
            list.remove(id)
            false
        } else {
            list.add(id)
            true
        }
        prefs.edit().putString(KEY, JSONArray(list).toString()).apply()
        return nowFav
    }

    private companion object {
        const val KEY = "favorites"
    }
}
