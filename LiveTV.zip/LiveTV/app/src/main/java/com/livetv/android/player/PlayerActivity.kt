package com.livetv.android.player

import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.livetv.android.R

/**
 * Full-screen native live player (Media3 ExoPlayer) with:
 *  - HLS / DASH / progressive auto-detection
 *  - optional per-channel User-Agent and Referer headers
 *  - automatic reconnect with back-off when a live stream drops
 *  - picture-in-picture with a play/pause action
 */
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var titleView: TextView
    private lateinit var errorBox: LinearLayout
    private lateinit var errorText: TextView
    private lateinit var retryBtn: Button

    private var streamUrl = ""
    private var channelName = ""
    private var userAgent = ""
    private var referer = ""

    private var retryCount = 0
    private var pipReceiverRegistered = false

    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_PIP_TOGGLE) return
            player?.let { if (it.isPlaying) it.pause() else it.play() }
            updatePipActions()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        playerView = findViewById(R.id.playerView)
        titleView = findViewById(R.id.titleView)
        errorBox = findViewById(R.id.errorBox)
        errorText = findViewById(R.id.errorText)
        retryBtn = findViewById(R.id.retryBtn)
        retryBtn.setOnClickListener {
            retryCount = 0
            startPlayback()
        }

        readIntent(intent)
        hideSystemBars()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
        retryCount = 0
        releasePlayer()
        startPlayback()
    }

    private fun readIntent(i: Intent) {
        streamUrl = i.getStringExtra(EXTRA_URL).orEmpty()
        channelName = i.getStringExtra(EXTRA_NAME).orEmpty()
        userAgent = i.getStringExtra(EXTRA_UA).orEmpty()
        referer = i.getStringExtra(EXTRA_REFERER).orEmpty()
        titleView.text = channelName
    }

    override fun onStart() {
        super.onStart()
        if (player == null) startPlayback()
    }

    override fun onStop() {
        super.onStop()
        // In PiP the activity is stopped but must keep playing, so only
        // release when we are NOT in picture-in-picture.
        if (!isInPip()) releasePlayer()
    }

    override fun onDestroy() {
        unregisterPipReceiver()
        releasePlayer()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- player

    private fun startPlayback() {
        if (streamUrl.isBlank()) {
            showError("No stream URL for this channel.")
            return
        }
        releasePlayer()
        errorBox.visibility = View.GONE

        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
        if (userAgent.isNotBlank()) http.setUserAgent(userAgent)
        if (referer.isNotBlank()) http.setDefaultRequestProperties(mapOf("Referer" to referer))

        // A slightly larger buffer keeps live streams smooth on weak networks.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 2_500, 5_000)
            .build()

        val exo = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(http))
            .setLoadControl(loadControl)
            .build()

        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) {
                    retryCount = 0
                    errorBox.visibility = View.GONE
                }
                updatePipActions()
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updatePipActions()
            }

            override fun onPlayerError(error: PlaybackException) {
                handleError(error)
            }
        })

        playerView.player = exo
        exo.setMediaItem(MediaItem.fromUri(streamUrl))
        exo.playWhenReady = true
        exo.prepare()
        player = exo
    }

    private fun handleError(error: PlaybackException) {
        val exo = player ?: return
        // Live streams behind the live window or with a dropped connection
        // can usually recover by seeking to the live edge and re-preparing.
        if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            exo.seekToDefaultPosition()
            exo.prepare()
            return
        }
        if (retryCount < MAX_RETRIES) {
            retryCount++
            val delay = retryCount * 2_000L
            playerView.postDelayed({
                val p = player ?: return@postDelayed
                p.prepare()
                p.playWhenReady = true
            }, delay)
            return
        }
        showError("Stream unavailable.\n${error.errorCodeName}")
    }

    private fun showError(message: String) {
        errorText.text = message
        errorBox.visibility = View.VISIBLE
    }

    private fun releasePlayer() {
        player?.let {
            playerView.player = null
            it.release()
        }
        player = null
    }

    // -------------------------------------------------------------- full screen

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isInPip()) hideSystemBars()
    }

    // ------------------------------------------------------------------- PiP

    private fun isInPip(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode

    private fun canPip(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature("android.software.picture_in_picture")

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Android 12+ can auto-enter via setAutoEnterEnabled; older versions
        // need this explicit call when the user presses Home.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) enterPip()
    }

    private fun enterPip() {
        if (!canPip()) return
        if (player?.isPlaying != true) return
        try {
            enterPictureInPictureMode(buildPipParams())
        } catch (_: Exception) {
            // Some devices / states refuse PiP; playback just continues normally.
        }
    }

    private fun buildPipParams(): PictureInPictureParams {
        val b = PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .setActions(pipActions())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            b.setAutoEnterEnabled(player?.isPlaying == true)
        }
        return b.build()
    }

    private fun pipActions(): List<RemoteAction> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return emptyList()
        val playing = player?.isPlaying == true
        val icon = Icon.createWithResource(
            this,
            if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )
        val title = getString(if (playing) R.string.pip_pause else R.string.pip_play)
        val pi = PendingIntent.getBroadcast(
            this, 0,
            Intent(ACTION_PIP_TOGGLE).setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return listOf(RemoteAction(icon, title, title, pi))
    }

    private fun updatePipActions() {
        if (!canPip()) return
        try {
            setPictureInPictureParams(buildPipParams())
        } catch (_: Exception) {
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            playerView.useController = false
            titleView.visibility = View.GONE
            registerPipReceiver()
        } else {
            playerView.useController = true
            titleView.visibility = View.VISIBLE
            unregisterPipReceiver()
            hideSystemBars()
        }
    }

    private fun registerPipReceiver() {
        if (pipReceiverRegistered) return
        ContextCompat.registerReceiver(
            this, pipReceiver, IntentFilter(ACTION_PIP_TOGGLE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        pipReceiverRegistered = true
    }

    private fun unregisterPipReceiver() {
        if (!pipReceiverRegistered) return
        try {
            unregisterReceiver(pipReceiver)
        } catch (_: Exception) {
        }
        pipReceiverRegistered = false
    }

    companion object {
        private const val EXTRA_URL = "url"
        private const val EXTRA_NAME = "name"
        private const val EXTRA_UA = "ua"
        private const val EXTRA_REFERER = "referer"
        private const val ACTION_PIP_TOGGLE = "com.livetv.android.PIP_TOGGLE"
        private const val MAX_RETRIES = 4

        fun start(
            context: Context,
            url: String,
            name: String,
            userAgent: String,
            referer: String
        ) {
            val i = Intent(context, PlayerActivity::class.java)
                .putExtra(EXTRA_URL, url)
                .putExtra(EXTRA_NAME, name)
                .putExtra(EXTRA_UA, userAgent)
                .putExtra(EXTRA_REFERER, referer)
            context.startActivity(i)
        }
    }
}
