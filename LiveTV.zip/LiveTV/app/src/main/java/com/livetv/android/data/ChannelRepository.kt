package com.livetv.android.data

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import org.json.JSONArray
import org.json.JSONObject

/**
 * Reads /channels from Firebase Realtime Database and keeps a live listener
 * attached so the app updates the moment an admin edits a channel.
 *
 * Only published channels are exposed. Unpublished ones are skipped here so
 * the UI never has to think about them.
 */
class ChannelRepository {

    private val ref by lazy { FirebaseDatabase.getInstance().getReference("channels") }
    private var listener: ValueEventListener? = null

    fun observe(onData: (String) -> Unit, onError: (String) -> Unit) {
        stop()
        val l = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                try {
                    onData(snapshotToJson(snapshot))
                } catch (e: Exception) {
                    onError("Could not read channels: ${e.message ?: "unknown error"}")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                onError(describe(error))
            }
        }
        listener = l
        try {
            ref.addValueEventListener(l)
        } catch (e: Exception) {
            onError("Firebase initialization failed: ${e.message ?: "unknown error"}")
        }
    }

    fun stop() {
        listener?.let { ref.removeEventListener(it) }
        listener = null
    }

    private fun snapshotToJson(snapshot: DataSnapshot): String {
        val items = ArrayList<JSONObject>()
        for (child in snapshot.children) {
            val published = child.child("published").getValue(Boolean::class.java) ?: true
            if (!published) continue

            val name = child.child("name").getValue(String::class.java).orEmpty().trim()
            val url = child.child("streamUrl").getValue(String::class.java).orEmpty().trim()
            if (name.isEmpty() || url.isEmpty()) continue

            val o = JSONObject()
            o.put("id", child.key ?: "")
            o.put("name", name)
            o.put("logo", child.child("logo").getValue(String::class.java).orEmpty().trim())
            o.put("streamUrl", url)
            o.put("category", child.child("category").getValue(String::class.java).orEmpty().trim().ifEmpty { "General" })
            o.put("country", child.child("country").getValue(String::class.java).orEmpty().trim())
            o.put("language", child.child("language").getValue(String::class.java).orEmpty().trim())
            o.put("description", child.child("description").getValue(String::class.java).orEmpty().trim())
            o.put("userAgent", child.child("userAgent").getValue(String::class.java).orEmpty().trim())
            o.put("referer", child.child("referer").getValue(String::class.java).orEmpty().trim())
            o.put("sortOrder", (child.child("sortOrder").value as? Number)?.toInt() ?: 0)
            items.add(o)
        }
        items.sortWith(compareBy({ it.optInt("sortOrder") }, { it.optString("name").lowercase() }))

        val arr = JSONArray()
        items.forEach { arr.put(it) }
        return arr.toString()
    }

    private fun describe(e: DatabaseError): String = when (e.code) {
        DatabaseError.PERMISSION_DENIED -> "Permission denied. Check your Firebase database rules."
        DatabaseError.NETWORK_ERROR -> "Network error. Check your connection."
        DatabaseError.DISCONNECTED -> "Disconnected from Firebase."
        else -> e.message.ifBlank { "Firebase error (${e.code})" }
    }
}
