package com.livetv.android.web

object TvHtml {
    fun page(): String = """<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:#0b0d12;color:#f5f7fb;font-family:Arial,sans-serif}
body{overflow-x:hidden;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}
input{user-select:text;-webkit-user-select:text}
button{border:0;font-family:inherit;cursor:pointer}
svg{display:block}
.top{position:sticky;top:0;z-index:10;background:#11141b;border-bottom:1px solid #242936}
.bar{display:flex;align-items:center;height:56px;padding:0 14px;gap:10px}
.brand{font-weight:800;font-size:20px}.brand b{color:#e50914}
.actions{margin-left:auto;display:flex;align-items:center;gap:2px}
.iconbtn{background:none;color:#fff;width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center}
.iconbtn:active{background:#1c212c}
.iconbtn svg{width:20px;height:20px;stroke:currentColor;fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.searchrow{display:none;padding:0 14px 10px}
.searchrow.show{display:block}
.search{width:100%;background:#151a23;border:1px solid #2a3140;color:#fff;padding:12px;border-radius:10px;font-size:15px;outline:none}
.tabs{display:flex;gap:8px;padding:0 14px 10px}
.tab{flex:1;background:#171c26;color:#b9c0cd;padding:10px;border-radius:10px;font-weight:700;font-size:14px}
.tab.on{background:#e50914;color:#fff}
.chips{display:flex;gap:8px;overflow-x:auto;padding:0 14px 12px;scrollbar-width:none}
.chips::-webkit-scrollbar{display:none}
.chip{flex:none;background:#171c26;color:#b9c0cd;padding:8px 14px;border-radius:20px;font-size:13px;white-space:nowrap}
.chip.on{background:#fff;color:#111;font-weight:700}
.main{padding:14px}
.count{font-size:12px;color:#8f98a8;margin:0 0 10px}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
.card{position:relative;background:#12161e;border:1px solid #242a36;border-radius:14px;overflow:hidden;min-width:0}
.card:active{transform:scale(.97)}
.logo{height:84px;display:flex;align-items:center;justify-content:center;background:#0f131a;padding:10px}
.logo img{max-width:100%;max-height:100%;object-fit:contain}
.logo .ph{font-size:26px;font-weight:800;color:#3a4356}
.meta{padding:8px 9px 10px}
.name{font-size:12.5px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.cat{font-size:11px;color:#8f98a8;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.fav{position:absolute;top:4px;right:4px;width:30px;height:30px;border-radius:50%;background:#0009;color:#fff;display:flex;align-items:center;justify-content:center}
.fav svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
.fav.on{color:#ff4d5a}
.live{position:absolute;top:8px;left:8px;background:#e50914;color:#fff;font-size:9px;font-weight:800;padding:2px 6px;border-radius:4px;letter-spacing:.5px}
.empty{padding:50px 20px;text-align:center;color:#818a9a;background:#11151c;border-radius:14px;grid-column:1/-1;line-height:1.5}
.skel{height:140px;border-radius:14px;background:linear-gradient(90deg,#12161e,#1a2029,#12161e);background-size:200% 100%;animation:sh 1.2s infinite}
@keyframes sh{0%{background-position:200% 0}100%{background-position:-200% 0}}
.toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#f5f7fb;color:#111;padding:11px 16px;border-radius:10px;z-index:99;display:none;max-width:90%;text-align:center;font-size:14px}

/* Professional authentication gate */
.auth{min-height:100vh;background:#0b0d12;display:none;align-items:center;justify-content:center;padding:24px 18px}
.auth.show{display:flex}
.auth-card{width:100%;max-width:420px;background:#11141b;border:1px solid #242936;border-radius:20px;padding:28px 22px 22px;box-shadow:0 18px 50px #0008}
.auth-logo{width:58px;height:58px;border-radius:16px;background:#e50914;display:flex;align-items:center;justify-content:center;margin:0 auto 18px}
.auth-logo svg{width:31px;height:31px;stroke:#fff;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.auth-title{text-align:center;font-size:24px;font-weight:800;margin:0}
.auth-sub{text-align:center;color:#8f98a8;font-size:13px;line-height:1.5;margin:8px 0 22px}
.auth-switch{display:flex;background:#171c26;padding:4px;border-radius:12px;margin-bottom:18px}
.auth-switch button{flex:1;padding:10px;border-radius:9px;background:transparent;color:#929aaa;font-weight:700;font-size:13px}
.auth-switch button.on{background:#242a36;color:#fff}
.field{margin-bottom:12px}
.field-label{display:block;color:#b9c0cd;font-size:12px;font-weight:700;margin:0 0 7px 2px}
.fieldbox{height:48px;display:flex;align-items:center;gap:10px;background:#151a23;border:1px solid #2a3140;border-radius:11px;padding:0 13px}
.fieldbox:focus-within{border-color:#747c8c}
.fieldbox svg{width:18px;height:18px;stroke:#858ea0;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round;flex:none}
.fieldbox input{flex:1;min-width:0;border:0;outline:0;background:transparent;color:#fff;font-size:14px}
.fieldbox input::placeholder{color:#667083}
.password-toggle{background:none;color:#858ea0;width:28px;height:30px;display:flex;align-items:center;justify-content:center}
.password-toggle svg{width:18px;height:18px}
.auth-primary{width:100%;height:48px;border-radius:11px;background:#e50914;color:#fff;font-size:14px;font-weight:800;margin-top:4px}
.auth-primary:active{transform:scale(.99)}
.google-btn{width:100%;height:48px;border-radius:11px;background:#f5f7fb;color:#111;border:1px solid #dfe3ea;display:flex;align-items:center;justify-content:center;gap:10px;font-size:14px;font-weight:800;margin-top:10px}
.google-btn svg{width:18px;height:18px}
.auth-or{display:flex;align-items:center;gap:10px;color:#687286;font-size:11px;margin:17px 0}
.auth-or:before,.auth-or:after{content:"";height:1px;background:#252b37;flex:1}
.auth-error{min-height:18px;color:#ff6b73;text-align:center;font-size:12px;margin:8px 0 2px;line-height:1.4}
.auth-note{text-align:center;color:#697386;font-size:11px;line-height:1.5;margin:16px 8px 0}
.auth-loading{opacity:.65;pointer-events:none}
@media(min-width:520px){.grid{grid-template-columns:repeat(4,1fr)}}
@media(min-width:760px){.grid{grid-template-columns:repeat(6,1fr)}}
</style>
</head>
<body>

<div class="auth show" id="auth">
  <div class="auth-card">
    <div class="auth-logo">
      <svg viewBox="0 0 24 24"><path d="M8 5l10 7-10 7z"/></svg>
    </div>
    <h1 class="auth-title">Welcome to Live TV</h1>
    <div class="auth-sub">Sign in to watch live channels and keep your favorites available across your sessions.</div>

    <div class="auth-switch">
      <button id="signInTab" class="on">Sign in</button>
      <button id="signUpTab">Create account</button>
    </div>

    <div class="field">
      <label class="field-label">Email address</label>
      <div class="fieldbox">
        <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>
        <input id="email" type="email" autocomplete="email" placeholder="Enter your email">
      </div>
    </div>

    <div class="field">
      <label class="field-label">Password</label>
      <div class="fieldbox">
        <svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg>
        <input id="password" type="password" autocomplete="current-password" placeholder="Enter your password">
        <button class="password-toggle" id="passwordToggle" type="button" aria-label="Show password">
          <svg viewBox="0 0 24 24"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/></svg>
        </button>
      </div>
    </div>

    <div class="field" id="confirmField" style="display:none">
      <label class="field-label">Confirm password</label>
      <div class="fieldbox">
        <svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 018 0v3"/></svg>
        <input id="confirmPassword" type="password" autocomplete="new-password" placeholder="Confirm your password">
      </div>
    </div>

    <div class="auth-error" id="authError"></div>
    <button class="auth-primary" id="submitAuth">Sign in</button>

    <div class="auth-or">OR</div>

    <button class="google-btn" id="googleBtn">
      <svg viewBox="0 0 24 24">
        <path fill="#4285F4" d="M21.6 12.23c0-.68-.06-1.33-.18-1.95H12v3.69h5.38a4.6 4.6 0 01-1.99 3.02v2.51h3.22c1.89-1.74 2.99-4.31 2.99-7.27z"/>
        <path fill="#34A853" d="M12 22c2.7 0 4.96-.9 6.61-2.44l-3.22-2.51c-.89.6-2.03.96-3.39.96-2.61 0-4.82-1.76-5.61-4.13H3.06v2.59A9.98 9.98 0 0012 22z"/>
        <path fill="#FBBC05" d="M6.39 13.88A6.01 6.01 0 016.07 12c0-.65.11-1.28.32-1.88V7.53H3.06A10 10 0 002 12c0 1.61.39 3.13 1.06 4.47l3.33-2.59z"/>
        <path fill="#EA4335" d="M12 5.99c1.47 0 2.79.51 3.83 1.5l2.87-2.87C16.96 2.92 14.7 2 12 2a9.98 9.98 0 00-8.94 5.53l3.33 2.59C7.18 7.75 9.39 5.99 12 5.99z"/>
      </svg>
      Continue with Google
    </button>

    <div class="auth-note">By continuing, you agree to use Live TV responsibly and comply with the service terms.</div>
  </div>
</div>

<div id="app" style="display:none">
<div class="top">
  <div class="bar">
    <div class="brand"><b>LIVE</b> TV</div>
    <div class="actions">
      <button class="iconbtn" id="searchBtn" aria-label="Search">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/></svg>
      </button>
      <button class="iconbtn" id="notificationsBtn" aria-label="Notifications">
        <svg viewBox="0 0 24 24"><path d="M18 9a6 6 0 00-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg>
      </button>
    </div>
  </div>
  <div class="searchrow" id="searchRow"><input class="search" id="q" placeholder="Search channels" autocomplete="off"></div>
  <div class="tabs">
    <button class="tab on" id="tabAll">All Channels</button>
    <button class="tab" id="tabFav">Favorites</button>
  </div>
  <div class="chips" id="chips"></div>
</div>
<div class="main">
  <div class="count" id="count"></div>
  <div class="grid" id="grid"></div>
</div>
</div>
<div class="toast" id="toast"></div>

<script>
var channels = [];
var favs = [];
var tab = 'all';
var category = 'All';
var query = '';
var loaded = false;
var transfers = {};
var authMode = 'signin';

function ${'$'}(id){ return document.getElementById(id); }
function esc(s){
  return String(s == null ? '' : s).replace(/[&<>"']/g, function(m){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
  });
}
function toast(t){
  var x = ${'$'}('toast'); x.textContent = t; x.style.display = 'block';
  clearTimeout(toast._t);
  toast._t = setTimeout(function(){ x.style.display = 'none'; }, 2200);
}
function loadFavs(){
  try { favs = JSON.parse(NativeTv.getFavorites() || '[]'); } catch(e){ favs = []; }
}
function isFav(id){ return favs.indexOf(id) >= 0; }

function showAuth(){
  ${'$'}('auth').className = 'auth show';
  ${'$'}('app').style.display = 'none';
  ${'$'}('authError').textContent = '';
}
function authSuccess(){
  ${'$'}('auth').className = 'auth';
  ${'$'}('app').style.display = 'block';
  loaded = false;
  drawGrid();
}
function authError(message){
  ${'$'}('authError').textContent = message || 'Authentication failed.';
  ${'$'}('submitAuth').classList.remove('auth-loading');
  ${'$'}('googleBtn').classList.remove('auth-loading');
}
function setAuthMode(mode){
  authMode = mode;
  var signup = mode === 'signup';
  ${'$'}('signInTab').className = signup ? '' : 'on';
  ${'$'}('signUpTab').className = signup ? 'on' : '';
  ${'$'}('confirmField').style.display = signup ? 'block' : 'none';
  ${'$'}('submitAuth').textContent = signup ? 'Create account' : 'Sign in';
  ${'$'}('password').setAttribute('autocomplete', signup ? 'new-password' : 'current-password');
  ${'$'}('authError').textContent = '';
}

${'$'}('signInTab').onclick = function(){ setAuthMode('signin'); };
${'$'}('signUpTab').onclick = function(){ setAuthMode('signup'); };

${'$'}('passwordToggle').onclick = function(){
  var p = ${'$'}('password');
  p.type = p.type === 'password' ? 'text' : 'password';
};

${'$'}('submitAuth').onclick = function(){
  var email = ${'$'}('email').value.trim();
  var password = ${'$'}('password').value;
  var confirm = ${'$'}('confirmPassword').value;
  ${'$'}('authError').textContent = '';
  if(!email || !email.includes('@')){ ${'$'}('authError').textContent = 'Enter a valid email address.'; return; }
  if(password.length < 6){ ${'$'}('authError').textContent = 'Password must be at least 6 characters.'; return; }
  if(authMode === 'signup' && password !== confirm){ ${'$'}('authError').textContent = 'Passwords do not match.'; return; }
  ${'$'}('submitAuth').classList.add('auth-loading');
  if(authMode === 'signup') NativeTv.createAccount(email, password);
  else NativeTv.signIn(email, password);
};

${'$'}('googleBtn').onclick = function(){
  ${'$'}('authError').textContent = '';
  ${'$'}('googleBtn').classList.add('auth-loading');
  NativeTv.googleSignIn();
};

${'$'}('notificationsBtn').onclick = function(){
  toast('No new notifications');
};

function categories(){
  var seen = {}, out = [];
  channels.forEach(function(c){
    var k = c.category || 'General';
    if(!seen[k]){ seen[k] = 1; out.push(k); }
  });
  out.sort(function(a,b){ return a.toLowerCase() < b.toLowerCase() ? -1 : 1; });
  return ['All'].concat(out);
}
function visible(){
  var q = query.trim().toLowerCase();
  return channels.filter(function(c){
    if(tab === 'fav' && !isFav(c.id)) return false;
    if(category !== 'All' && (c.category || 'General') !== category) return false;
    if(q){
      var hay = (c.name + ' ' + (c.category||'') + ' ' + (c.country||'') + ' ' + (c.language||'')).toLowerCase();
      if(hay.indexOf(q) < 0) return false;
    }
    return true;
  });
}
function drawChips(){
  var cats = categories();
  if(cats.indexOf(category) < 0) category = 'All';
  ${'$'}('chips').innerHTML = cats.map(function(c){
    return '<button class="chip' + (c === category ? ' on' : '') + '" data-cat="' + esc(c) + '">' + esc(c) + '</button>';
  }).join('');
}
function heartIcon(on){
  return '<svg viewBox="0 0 24 24"><path d="M20.8 8.9c0 5.1-8.8 10.2-8.8 10.2S3.2 14 3.2 8.9A4.7 4.7 0 017.9 4.2c1.4 0 2.9.7 4.1 2 1.2-1.3 2.7-2 4.1-2a4.7 4.7 0 014.7 4.7z"' + (on ? ' fill="currentColor"' : '') + '/></svg>';
}
function drawGrid(){
  var g = ${'$'}('grid');
  if(!loaded){
    g.innerHTML = new Array(9).join('<div class="skel"></div>');
    ${'$'}('count').textContent = '';
    return;
  }
  var list = visible();
  ${'$'}('count').textContent = list.length ? (list.length + (list.length === 1 ? ' channel' : ' channels')) : '';
  if(!list.length){
    var msg = tab === 'fav'
      ? 'No favorites yet.<br>Tap the heart on any channel to save it here.'
      : (channels.length ? 'No channels match your search.' : 'No channels available right now.');
    g.innerHTML = '<div class="empty">' + msg + '</div>';
    return;
  }
  g.innerHTML = list.map(function(c){
    var logo = c.logo
      ? '<img src="' + esc(c.logo) + '" loading="lazy" onerror="this.parentNode.innerHTML=\'<span class=&quot;ph&quot;>' + esc((c.name||'?').charAt(0).toUpperCase()) + '</span>\'">'
      : '<span class="ph">' + esc((c.name||'?').charAt(0).toUpperCase()) + '</span>';
    return '<div class="card" data-id="' + esc(c.id) + '">' +
      '<span class="live">LIVE</span>' +
      '<button class="fav' + (isFav(c.id) ? ' on' : '') + '" data-fav="' + esc(c.id) + '" aria-label="Favorite">' + heartIcon(isFav(c.id)) + '</button>' +
      '<div class="logo">' + logo + '</div>' +
      '<div class="meta"><div class="name">' + esc(c.name) + '</div><div class="cat">' + esc(c.category || 'General') + '</div></div>' +
    '</div>';
  }).join('');
}
function render(){ drawChips(); drawGrid(); }
function findChannel(id){
  for(var i = 0; i < channels.length; i++){ if(channels[i].id === id) return channels[i]; }
  return null;
}
${'$'}('grid').addEventListener('click', function(e){
  var favBtn = e.target.closest ? e.target.closest('[data-fav]') : null;
  if(favBtn){
    e.stopPropagation();
    var id = favBtn.getAttribute('data-fav');
    var now = NativeTv.toggleFavorite(id);
    loadFavs();
    toast(now ? 'Added to favorites' : 'Removed from favorites');
    if(tab === 'fav') drawGrid();
    else { favBtn.className = 'fav' + (now ? ' on' : ''); favBtn.innerHTML = heartIcon(now); }
    return;
  }
  var card = e.target.closest ? e.target.closest('.card') : null;
  if(!card) return;
  var c = findChannel(card.getAttribute('data-id'));
  if(c) NativeTv.play(c.streamUrl, c.name, c.userAgent || '', c.referer || '');
});
${'$'}('chips').addEventListener('click', function(e){
  var b = e.target.closest ? e.target.closest('[data-cat]') : null;
  if(!b) return;
  category = b.getAttribute('data-cat');
  render();
});
function setTab(t){
  tab = t;
  ${'$'}('tabAll').className = 'tab' + (t === 'all' ? ' on' : '');
  ${'$'}('tabFav').className = 'tab' + (t === 'fav' ? ' on' : '');
  loadFavs();
  drawGrid();
}
${'$'}('tabAll').onclick = function(){ setTab('all'); };
${'$'}('tabFav').onclick = function(){ setTab('fav'); };
${'$'}('searchBtn').onclick = function(){
  var row = ${'$'}('searchRow');
  var open = row.className.indexOf('show') >= 0;
  if(open){ closeSearch(); }
  else { row.className = 'searchrow show'; ${'$'}('q').focus(); }
};
function closeSearch(){
  ${'$'}('searchRow').className = 'searchrow';
  ${'$'}('q').value = ''; query = ''; ${'$'}('q').blur();
  drawGrid();
}
${'$'}('q').addEventListener('input', function(){ query = this.value; drawGrid(); });

window.TvUI = {
  showAuth: showAuth,
  authSuccess: authSuccess,
  authError: authError,
  dataStart: function(id, total){ transfers[id] = { total: total, chunks: [] }; },
  dataChunk: function(id, index, chunk){ if(transfers[id]) transfers[id].chunks[index] = chunk; },
  dataEnd: function(id){
    var t = transfers[id]; if(!t) return;
    delete transfers[id];
    try {
      var parsed = JSON.parse(t.chunks.join('') || '[]');
      channels = Array.isArray(parsed) ? parsed : [];
      loaded = true;
      loadFavs();
      render();
    } catch(e){
      loaded = true;
      toast('Could not read channel list');
      render();
    }
  },
  onError: function(msg){
    loaded = true;
    toast(msg || 'Could not load channels');
    render();
  },
  onBack: function(){
    if(${'$'}('auth').className.indexOf('show') >= 0) return false;
    if(${'$'}('searchRow').className.indexOf('show') >= 0){ closeSearch(); return true; }
    if(tab === 'fav'){ setTab('all'); return true; }
    if(category !== 'All'){ category = 'All'; render(); return true; }
    return false;
  }
};

loadFavs();
NativeTv.ready();
</script>
</body>
</html>
""".trimIndent()

}
